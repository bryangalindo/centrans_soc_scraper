--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.vendors DROP CONSTRAINT vendors_vendorname_key;
ALTER TABLE ONLY public.vendors DROP CONSTRAINT vendors_pkey;
ALTER TABLE ONLY public.vendor_tracking_urls DROP CONSTRAINT vendor_tracking_urls_url_key;
ALTER TABLE ONLY public.vendor_emails DROP CONSTRAINT vendor_emails_email_key;
ALTER TABLE ONLY public.depots DROP CONSTRAINT depots_pkey;
ALTER TABLE ONLY public.depot_tracking_urls DROP CONSTRAINT depot_tracking_urls_url_key;
ALTER TABLE ONLY public.depot_phone_numbers DROP CONSTRAINT depot_phone_numbers_phone_num_key;
ALTER TABLE ONLY public.depot_emails DROP CONSTRAINT depot_emails_email_key;
ALTER TABLE ONLY public.tracker DROP CONSTRAINT containers_pkey;
ALTER TABLE public.vendors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tracker ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.depots ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.vendors_id_seq;
DROP TABLE public.vendors;
DROP TABLE public.vendor_tracking_urls;
DROP TABLE public.vendor_emails;
DROP SEQUENCE public.depots_id_seq;
DROP TABLE public.depots;
DROP TABLE public.depot_tracking_urls;
DROP TABLE public.depot_phone_numbers;
DROP TABLE public.depot_emails;
DROP SEQUENCE public.containers_id_seq;
DROP TABLE public.tracker;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tracker; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tracker (
    id integer NOT NULL,
    reference_number text NOT NULL,
    container_number text NOT NULL,
    move_type text NOT NULL,
    last_free_day date NOT NULL,
    date_created date DEFAULT CURRENT_DATE NOT NULL,
    date_returned date,
    vendor_id integer,
    depot_id integer
);


ALTER TABLE public.tracker OWNER TO postgres;

--
-- Name: containers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.containers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.containers_id_seq OWNER TO postgres;

--
-- Name: containers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.containers_id_seq OWNED BY public.tracker.id;


--
-- Name: depot_emails; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.depot_emails (
    depot_id integer,
    email text
);


ALTER TABLE public.depot_emails OWNER TO postgres;

--
-- Name: depot_phone_numbers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.depot_phone_numbers (
    depot_id integer,
    phone_num text
);


ALTER TABLE public.depot_phone_numbers OWNER TO postgres;

--
-- Name: depot_tracking_urls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.depot_tracking_urls (
    depot_id integer,
    url text
);


ALTER TABLE public.depot_tracking_urls OWNER TO postgres;

--
-- Name: depots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.depots (
    id integer NOT NULL,
    depot text
);


ALTER TABLE public.depots OWNER TO postgres;

--
-- Name: depots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.depots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.depots_id_seq OWNER TO postgres;

--
-- Name: depots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.depots_id_seq OWNED BY public.depots.id;


--
-- Name: vendor_emails; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendor_emails (
    vendor_id integer,
    email text
);


ALTER TABLE public.vendor_emails OWNER TO postgres;

--
-- Name: vendor_tracking_urls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendor_tracking_urls (
    vendor_id integer,
    url text
);


ALTER TABLE public.vendor_tracking_urls OWNER TO postgres;

--
-- Name: vendors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors (
    id integer NOT NULL,
    vendor text
);


ALTER TABLE public.vendors OWNER TO postgres;

--
-- Name: vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vendors_id_seq OWNER TO postgres;

--
-- Name: vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vendors_id_seq OWNED BY public.vendors.id;


--
-- Name: depots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depots ALTER COLUMN id SET DEFAULT nextval('public.depots_id_seq'::regclass);


--
-- Name: tracker id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracker ALTER COLUMN id SET DEFAULT nextval('public.containers_id_seq'::regclass);


--
-- Name: vendors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors ALTER COLUMN id SET DEFAULT nextval('public.vendors_id_seq'::regclass);


--
-- Data for Name: depot_emails; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.depot_emails (depot_id, email) FROM stdin;
\.
COPY public.depot_emails (depot_id, email) FROM '$$PATH$$/3177.dat';

--
-- Data for Name: depot_phone_numbers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.depot_phone_numbers (depot_id, phone_num) FROM stdin;
\.
COPY public.depot_phone_numbers (depot_id, phone_num) FROM '$$PATH$$/3178.dat';

--
-- Data for Name: depot_tracking_urls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.depot_tracking_urls (depot_id, url) FROM stdin;
\.
COPY public.depot_tracking_urls (depot_id, url) FROM '$$PATH$$/3180.dat';

--
-- Data for Name: depots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.depots (id, depot) FROM stdin;
\.
COPY public.depots (id, depot) FROM '$$PATH$$/3175.dat';

--
-- Data for Name: tracker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tracker (id, reference_number, container_number, move_type, last_free_day, date_created, date_returned, vendor_id, depot_id) FROM stdin;
\.
COPY public.tracker (id, reference_number, container_number, move_type, last_free_day, date_created, date_returned, vendor_id, depot_id) FROM '$$PATH$$/3171.dat';

--
-- Data for Name: vendor_emails; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendor_emails (vendor_id, email) FROM stdin;
\.
COPY public.vendor_emails (vendor_id, email) FROM '$$PATH$$/3176.dat';

--
-- Data for Name: vendor_tracking_urls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendor_tracking_urls (vendor_id, url) FROM stdin;
\.
COPY public.vendor_tracking_urls (vendor_id, url) FROM '$$PATH$$/3179.dat';

--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors (id, vendor) FROM stdin;
\.
COPY public.vendors (id, vendor) FROM '$$PATH$$/3173.dat';

--
-- Name: containers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.containers_id_seq', 62, true);


--
-- Name: depots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.depots_id_seq', 100, true);


--
-- Name: vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vendors_id_seq', 54, true);


--
-- Name: tracker containers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracker
    ADD CONSTRAINT containers_pkey PRIMARY KEY (id);


--
-- Name: depot_emails depot_emails_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depot_emails
    ADD CONSTRAINT depot_emails_email_key UNIQUE (email);


--
-- Name: depot_phone_numbers depot_phone_numbers_phone_num_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depot_phone_numbers
    ADD CONSTRAINT depot_phone_numbers_phone_num_key UNIQUE (phone_num);


--
-- Name: depot_tracking_urls depot_tracking_urls_url_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depot_tracking_urls
    ADD CONSTRAINT depot_tracking_urls_url_key UNIQUE (url);


--
-- Name: depots depots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depots
    ADD CONSTRAINT depots_pkey PRIMARY KEY (id);


--
-- Name: vendor_emails vendor_emails_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendor_emails
    ADD CONSTRAINT vendor_emails_email_key UNIQUE (email);


--
-- Name: vendor_tracking_urls vendor_tracking_urls_url_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendor_tracking_urls
    ADD CONSTRAINT vendor_tracking_urls_url_key UNIQUE (url);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_vendorname_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_vendorname_key UNIQUE (vendor);


--
-- PostgreSQL database dump complete
--

